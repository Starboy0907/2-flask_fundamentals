# dojo_fruit_store
/*Learn how to access the form submission data in our server

Accessing Data: request.form['name_of_input'] 
# This is syntax for accessing data..quotations are important. 
The name we gave to each HTML input was significant. 
# You should look for the name of the input. This is used for the right side of the declaration on the route and should match the input in html. The left-side of the declaration is the variable that may be set at the developers descretion.


 On the server-side, we can access data that was input into a field from a user through the request.form dictionary by providing the name of the input as the key.
# The dictionary is initialized in the function on the server side.  
# The dictionary is used for the jinja variables in the html.
To see what's in your request object, try printing request.form.
# You can check your print statements in the terminal.

*/


